Demo.prototype.init = function()
{
    var start = 0;
    var duration = Settings.demo.length;
    var layer = 1;

    this.loader.addAnimation({
         "start": start, "duration":duration
        ,"layer": layer, "image": Settings.demo.custom.background
        ,"scale":JSON.parse("["+(Settings.demo.custom.farjan.background.scale.v||"{}")+"]")
        ,"position":JSON.parse("["+(Settings.demo.custom.farjan.background.position.v||'{"x":"{return getScreenWidth()/2;}","y":"{ return getScreenHeight()/2;}"}')+"]")
        ,"angle":JSON.parse("["+(Settings.demo.custom.farjan.background.angle.v||"{}")+"]")
    });

    if (Settings.demo.custom.farjan.sun.shadow.v) {
        this.loader.addAnimation({
             "start": start, "duration":duration
            ,"layer": layer, "image": Settings.demo.custom.sun
            ,"position":[{"x":1700,"y":"{return Math.sin(getSceneTimeFromStart())*20+900;}"}]
            ,"color":[{"r":0,"g":0,"b":0}]
            ,"scale":[{"uniform2d":0.6}]
        });
    }
    this.loader.addAnimation({
         "start": start, "duration":duration
        ,"layer": layer, "image": Settings.demo.custom.sun
        ,"position":[{"x":1700,"y":900}]
        ,"scale":[{"uniform2d":0.6}]
    });


    var fpos = Settings.demo.custom.farjan.ferry.position;
    var fangle = Settings.demo.custom.farjan.ferry.angle;
    this.loader.addAnimation({
         "start": start, "duration":duration
        ,"layer": layer, "image": Settings.demo.custom.ferry
        ,"position":JSON.parse("["+(fpos.v||"{}")+"]")
        ,"angle":JSON.parse("["+(fangle.v||"{}")+"]")
    });

    this.loader.addAnimation({
         "start": start, "duration":duration
        ,"layer": layer, "image": Settings.demo.custom.foreground
        ,"scale":JSON.parse("["+(Settings.demo.custom.farjan.foreground.scale.v||"{}")+"]")
        ,"position":JSON.parse("["+(Settings.demo.custom.farjan.foreground.position.v||'{"x":"{return getScreenWidth()/2;}","y":"{ return getScreenHeight()/2;}"}')+"]")
        ,"angle":JSON.parse("["+(Settings.demo.custom.farjan.foreground.angle.v||"{}")+"]")
    });

    var scroller = Settings.demo.custom.farjan.scroller.v;
    this.loader.addAnimation([
    {
         "start": 0, "duration": duration
        ,"layer": 201, "text":{"name":Settings.demo.custom.font,"string":scroller}
        ,"scale":JSON.parse("["+(Settings.demo.custom.farjan.font.scale.v||"{}")+"]")
        ,"angle":JSON.parse("["+(Settings.demo.custom.farjan.font.angle.v||"{}")+"]")
        ,"position":JSON.parse("["+(Settings.demo.custom.farjan.font.position.v||"{}")+"]")
        ,"color": JSON.parse("["+(Settings.demo.custom.farjan.font.color.v||"{}")+"]")
    }]);
}
